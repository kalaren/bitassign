citylist = ["Toronto", "Oakville", "Tokyo", "San Francisco", "Hong Kong"]

citylist.each do |city|
	puts city
end
